<?php

require_once("PHPMailer/PHPMailerAutoload.php"); //including PHPMailerAutoload
require_once("core/FeedbackNow.php");			 //including FeedbackNow php class

$config  = array("imagesDirectory"=> $_SERVER["DOCUMENT_ROOT"] . "/uploads/"); //directory that will store the images of the feedback

try{
	$FeedbackNow = FeedbackNow::createSingleton($config);	//instantiating singleton object of class feedbackNow

	$mail             = $FeedbackNow->phpmailer;			//instance of PHPMailer

/*	$mail->isSMTP();                                      	// Set mailer to use SMTP
	$mail->Host       = 'smtp.gmail.com';  					// Specify main and backup SMTP servers
	$mail->SMTPAuth   = true;                               // Enable SMTP authentication
	$mail->Username   = 'tuyoshi.mail@gmail.com';           // SMTP username
	$mail->Password   = 'tv1q2w3e4r';                       // SMTP password
	$mail->SMTPSecure = 'tls';                            	// Enable TLS encryption, `ssl` also accepted
	$mail->Port       = 587;                                // TCP port to connect to*/


	$mail->CharSet = 'UTF-8';
	$mail->From     = "tuyoshi.mail@gmail.com";						
	$mail->FromName = "User System";						
	$mail->addReplyTo($FeedbackNow->email);

	$mail->addAddress("tuyoshi.vinicius@gmail.com");
	$mail->addCC($FeedbackNow->email);						//Add a "CC" address.

	$status = $mail->send();

	print json_encode(array( "status"=> $status ));

} catch (Exception $e) {   	 
 	 print json_encode(array( "status"=>false, "message"=> $e->getMessage() ));
}